<!-- Content Header (Page header) -->
<section class="content-header">
       <h1>
              Supplier
              <small>Data Supplier</small>
       </h1>
       <ol class="breadcrumb">
              <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
              <li class="active">Supplier</li>
       </ol>
</section>

<!-- Main content -->
<section class="content">
       <!-- Data tabel -->
       <div class="box">
              <div class="box-header">
                     <h3 class="box-title">Data Supplier</h3>
                     <div class="pull-right">
                            <a href="<?= base_url('supplier/add') ?>" class="btn btn-primary"><i class="fa fa-user-plus"> Add</i></a>
                     </div>
              </div>
              <div class="box-body">
                     <table id="dataTable" class="table table-hover table-bordered">
                            <thead>
                                   <tr>
                                          <th>No</th>
                                          <th>Nama Supplier</th>
                                          <th>Phone</th>
                                          <th>Email</th>
                                          <th>Address</th>
                                          <th>Description</th>
                                          <th>Action</th>
                                   </tr>
                            </thead>
                            <tbody>
                                   <tr>
                                          <td>1</td>
                                          <td>PT Tes AJA</td>
                                          <td>0938493</td>
                                          <td>Jakarta</td>
                                          <td>indonusa@gmail.com</td>
                                          <td>Jualan Pasir</td>
                                          <td>
                                                 <a class="btn btn-primary  btn-xs"><i class="fa fa-edit"> Edit</i></a>
                                                 <a class="btn btn-danger btn-xs"><i class="fa fa-edit"> Delete</i></a>
                                          </td>
                                   </tr>
                            </tbody>
                     </table>
              </div>
       </div>
</section>
<!-- /.content -->