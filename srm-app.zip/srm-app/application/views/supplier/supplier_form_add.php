<!-- Content Header (Page header) -->
<section class="content-header">
       <h1>
              Suppliers
              <small>Pemasok Barang</small>
       </h1>
       <ol class="breadcrumb">
              <li><a href="<?= base_url('dashboard') ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
              <li class="active">Suppliers</li>
       </ol>
</section>

<!-- =============================================== -->
<!-- Main content -->
<section class="content">
       <div class="box">
              <div class="box-header">
                     <h3 class="box-title">Add Suppliers</h3>
                     <div class="pull-right">
                            <a href="<?= base_url('supplier') ?>" class="btn btn-warning btn-flat">
                                   <i class="fa fa-undo"></i> Back
                            </a>
                     </div>
              </div>
              <div class="box-body">
                     <div class="row" padding="10px">
                            <div class="col-md-4 col-md-offset-4">
                                   <?php //echo validation_errors(); 
                                   ?>
                                   <form action="" method="post">
                                          <div class="form-group">
                                                 <label for="">Supplier Name *</label>
                                                 <input type="text" name="suppliername" value="" class="form-control" placeholder="Name Supplier">
                                          </div>
                                          <div class="">
                                                 <label for="">Phone *</label>
                                                 <input type="number" name="phonesupplier" value="" class="form-control" placeholder="Phone">
                                          </div>
                                          <div class="">
                                                 <label for="">Email *</label>
                                                 <input type="text" name="phonesupplier" value="" class="form-control" placeholder="Email">
                                          </div>
                                          <div class="form-group">
                                                 <label for="">Address Supplier *</label>
                                                 <textarea name="address" value="" class="form-control" placeholder="Address"></textarea>
                                          </div>
                                          <div class="form-group">
                                                 <label for="">Description</label>
                                                 <textarea name="desc" value="" class="form-control" placeholder="Description"></textarea>
                                          </div>
                                          <div class="form-group">
                                                 <button type="submit" class="btn btn-primary btn-flat"><i class="fa fa-paper-plane"></i> Save</button>
                                                 <button type="reset" class="btn btn-danger btn-flat"><i class="fa  fa-remove"></i> Reset</button>
                                          </div>
                                   </form>
                            </div>
                     </div>
              </div>
       </div>
</section>
<!-- /.content -->