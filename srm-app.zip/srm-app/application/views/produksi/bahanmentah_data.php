<!-- Content Header (Page header) -->
<section class="content-header">
       <h1>
              Bahan Mentah
              <small>Control panel</small>
       </h1>
       <ol class="breadcrumb">
              <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
              <li class="active">Bahan Mentah</li>
       </ol>
</section>

<!-- Main content -->
<section class="content">
       <!-- Data tabel -->
       <div class="box">
              <div class="box-header">
                     <h3 class="box-title">Data Bahan Mentah</h3>
                     <div class="pull-right">
                            <a href="" class="btn btn-primary"><i class="fa fa-user-plus"> Add</i></a>
                     </div>
              </div>
              <div class="box-body">
                     <table id="dataTable" class="table table-hover table-bordered">
                            <thead>
                                   <tr>
                                          <th>No</th>
                                          <th>Nama Supplier</th>
                                          <th>Nama Barang</th>
                                          <th>Waktu In</th>
                                          <th>Qty</th>
                                          <th>Status</th>
                                          <th>Action</th>
                                   </tr>
                            </thead>
                            <tbody>
                                   <tr>
                                          <td>1</td>
                                          <td>PT Tes AJA</td>
                                          <td>Batu Bata</td>
                                          <td>20/09/2019</td>
                                          <td>20</td>
                                          <td>proses</td>
                                          <td>
                                                 <a class="btn btn-primary  btn-xs"><i class="fa fa-edit"> Edit</i></a>
                                                 <a class="btn btn-danger btn-xs"><i class="fa fa-edit"> Delete</i></a>
                                          </td>
                                   </tr>
                            </tbody>
                     </table>
              </div>
       </div>
</section>
<!-- /.content -->